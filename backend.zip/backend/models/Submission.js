const mongoose = require('mongoose');

const submissionSchema = new mongoose.Schema({
  assignmentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Assignment',
    required: false
  },
  problemId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Problem',
    required: true
  },
  studentId: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  code: {
    type: String,
    required: true
  },
  language: {
    type: String,
    required: true,
    enum: ['javascript', 'python', 'java', 'c', 'cpp', 'csharp', 'go', 'ruby', 'php', 'rust', 'typescript']
  },
  status: {
    type: String,
    enum: ['pending', 'running', 'accepted', 'wrong_answer', 'time_limit_exceeded', 'memory_limit_exceeded', 'runtime_error', 'compilation_error'],
    default: 'pending'
  },
  testResults: [{
    testCase: {
      input: String,
      expectedOutput: String
    },
    actualOutput: String,
    passed: Boolean,
    isHidden: Boolean,
    errorType: String,
    executionTime: Number, 
    memoryUsed: Number 
  }],
  score: {
    type: Number,
    default: 0,
    min: 0,
    max: 100
  },
  feedback: {
    type: String,
    default: ''
  },
  aiAnalysis: {
    timeComplexity: String,
    spaceComplexity: String,
    readability: String,
    naming: String,
    optimization: String,
    bugs: String,
    bestPractices: String
  },
  passedTestCases: {
    type: Number,
    default: 0
  },
  totalTestCases: {
    type: Number,
    default: 0
  },
  errorMessage: {
    type: String,
    default: ''
  },
  executionTime: {
    type: Number,
    default: 0
  },
  memoryUsed: {
    type: Number,
    default: 0
  },
  gradedBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  gradedAt: Date,
  submittedAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  },
  isDraft: {
    type: Boolean,
    default: false
  },
  isPractice: {
    type: Boolean,
    default: false
  }
});


submissionSchema.pre('save', function(next) {
  this.updatedAt = Date.now();
  next();
});


submissionSchema.index({ assignmentId: 1, studentId: 1, problemId: 1 });
submissionSchema.index({ studentId: 1, submittedAt: -1 });
submissionSchema.index({ status: 1, submittedAt: -1 });

module.exports = mongoose.model('Submission', submissionSchema);